import asyncio
import json
import logging
import os
import subprocess
from typing import Any, Awaitable, Callable, Optional, Union

import anyio
from claude_agent_sdk import (
    ClaudeAgentOptions,
    ClaudeSDKClient,
    create_sdk_mcp_server,
    tool,
)
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)


class ComputerAgent:
    """Claude-based computer agent using Claude Agent SDK."""

    def __init__(self, user_id: str = "anonymous"):
        self.user_id = user_id
        self.options: Optional[ClaudeAgentOptions] = None
        self.client: Optional[ClaudeSDKClient] = None
        self.message_sender: Optional[Callable[[dict], Awaitable[None]]] = None

    def set_message_sender(self, sender: Callable[[dict], Awaitable[None]]) -> None:
        """Register the callback used to send messages back to the voice agent."""
        self.message_sender = sender

    async def _send_message_helper(self, message: Union[str, dict]) -> None:
        """Helper to send message via the instance callback."""
        if not self.message_sender:
            logger.error("Message sender not configured")
            return

        try:
            payload = json.loads(message) if isinstance(message, str) else message
        except json.JSONDecodeError:
            logger.error("send_message_to_voice_agent expects JSON-serializable input")
            return

        if not isinstance(payload, dict):
            logger.error("Payload must be a dict")
            return

        try:
            await self.message_sender(payload)
        except Exception as e:
            logger.error(f"Failed to send message: {e}", exc_info=True)

    async def initialize(self) -> None:
        """Initialize the agent with SDK client."""
        try:
            # Define tools as closures to capture self/context safely

            @tool(
                "send_message_to_voice_agent",
                "Send a progress update or response to the voice agent.",
                {"message": str},
            )
            async def send_message_tool(args: dict[str, Any]) -> dict[str, Any]:
                """Tool to send messages back to the voice agent."""
                message = args.get("message")
                await self._send_message_helper(message)
                return {
                    "content": [
                        {"type": "text", "text": "Message sent to voice agent."}
                    ]
                }

            # Create MCP server configuration with our tools
            mcp_server = create_sdk_mcp_server(
                name="computer_tools",
                version="1.0.0",
                tools=[send_message_tool],
            )

            # Define Playwright MCP server configuration
            playwright_mcp = {
                "command": "npx",
                "args": ["-y", "@playwright/mcp@latest"],
            }

            # Configure agent options
            self.options = ClaudeAgentOptions(
                system_prompt=self._get_system_prompt(),
                mcp_servers={
                    "computer": mcp_server,
                    "playwright": playwright_mcp,
                },
                permission_mode="bypassPermissions",
            )
            
            # Initialize the stateful client once per session
            self.client = ClaudeSDKClient(options=self.options)
            await self.client.connect()

            # Check critical environment variables
            if not os.getenv("ANTHROPIC_API_KEY"):
                logger.warning("ANTHROPIC_API_KEY is not set!")
            
            base_url = os.getenv("ANTHROPIC_BASE_URL")
            if base_url:
                logger.info(f"Using custom ANTHROPIC_BASE_URL: {base_url}")
            else:
                logger.info("Using default Anthropic API URL")

            logger.info("Claude SDK agent initialized successfully")

        except Exception as e:
            logger.error(f"Failed to initialize agent: {e}", exc_info=True)
            raise

    def _get_system_prompt(self) -> str:
        return """You are a computer assistant, a backend automation agent supporting the voice agent in executing tasks for users.
You have access to a bash shell to execute commands via the built-in 'bash' tool.
You also have access to a web browser via Playwright MCP tools to perform web automation and research.

GUIDELINES:
1. Report progress only when important milestones are reached or when the task is completed. Avoid frequent trivial updates.
   - Statuses: 'running', 'completed', 'needs_input', 'error'.
   - Include a 'message' description.
   - Include the 'session_id' provided in the task.
2. Break complex tasks into steps.
3. Use the 'bash' tool for system operations.
4. Use Playwright tools (e.g., navigate, click, input) for web tasks.
5. If user input is needed, use status 'needs_input' and provide 'required_input' details.
6. When the task is done, send a 'completed' status update with the final result.

Message format for 'send_message_to_voice_agent' (pass as JSON string):
{
  "type": "task_update",
  "status": "running" | "completed" | "needs_input",
  "progress": 50,
  "message": "Description of milestone or completion...",
  "session_id": "..."
}
"""

    async def run_task_stream(self, task: str, session_id: str):
        """Run a task with Claude SDK and stream interaction."""
        if not self.client:
            raise RuntimeError("Agent not initialized")

        prompt = f"Task: {task}\nSession ID: {session_id}"

        try:
            # Use the persistent client to process the query
            # Trying process_query which is likely the internal streaming method
            # If query() returns None, it might be for non-streaming or CLI output.
            if hasattr(self.client, "process_query"):
                stream = self.client.process_query(prompt=prompt)
            else:
                # Fallback to query, handling potential coroutine
                stream = self.client.query(prompt=prompt)
                if asyncio.iscoroutine(stream):
                    stream = await stream

            if stream:
                async for message in stream:
                    # Log messages for debugging
                    logger.debug(f"Claude message: {message}")
                    pass
            else:
                logger.error("Query returned None/No stream")

        except Exception as e:
            # Handle exception groups (Python 3.11+)
            # anyio.ExceptionGroup is deprecated/removed in newer versions in favor of built-in
            if isinstance(e, BaseExceptionGroup):
                for exc in e.exceptions:
                    logger.error(f"Sub-exception in agent execution: {exc}")
            else:
                logger.error(f"Error in agent execution: {e}", exc_info=True)
            
            # Send error to voice agent
            if self.message_sender:
                err_msg = {
                    "type": "task_update",
                    "status": "error",
                    "message": str(e),
                    "session_id": session_id,
                }
                await self._send_message_helper(json.dumps(err_msg))

    async def cleanup(self):
        """Cleanup resources."""
        if self.client:
            await self.client.close()
        pass
